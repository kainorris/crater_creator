/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define B1_EXTI_IRQn EXTI15_10_IRQn
#define PWR_EN_R_Pin GPIO_PIN_0
#define PWR_EN_R_GPIO_Port GPIOC
#define PWR_EN_L_Pin GPIO_PIN_0
#define PWR_EN_L_GPIO_Port GPIOA
#define USART_TX_Pin GPIO_PIN_2
#define USART_TX_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define INT_C_Pin GPIO_PIN_4
#define INT_C_GPIO_Port GPIOA
#define INT_C_EXTI_IRQn EXTI4_IRQn
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define PWR_EN_C_Pin GPIO_PIN_0
#define PWR_EN_C_GPIO_Port GPIOB
#define LPn_L_Pin GPIO_PIN_10
#define LPn_L_GPIO_Port GPIOB
#define INT_L_Pin GPIO_PIN_7
#define INT_L_GPIO_Port GPIOC
#define INT_L_EXTI_IRQn EXTI9_5_IRQn
#define I2C_RST_L_Pin GPIO_PIN_8
#define I2C_RST_L_GPIO_Port GPIOA
#define I2C_RST_R_Pin GPIO_PIN_9
#define I2C_RST_R_GPIO_Port GPIOA
#define INT_R_Pin GPIO_PIN_10
#define INT_R_GPIO_Port GPIOA
#define INT_R_EXTI_IRQn EXTI15_10_IRQn
#define TMS_Pin GPIO_PIN_13
#define TMS_GPIO_Port GPIOA
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define I2C_RST_C_Pin GPIO_PIN_3
#define I2C_RST_C_GPIO_Port GPIOB
#define LPn_C_Pin GPIO_PIN_4
#define LPn_C_GPIO_Port GPIOB
#define LPn_R_Pin GPIO_PIN_5
#define LPn_R_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
